typedef struct  {
    int busy;
    int floor;

}elevator;
