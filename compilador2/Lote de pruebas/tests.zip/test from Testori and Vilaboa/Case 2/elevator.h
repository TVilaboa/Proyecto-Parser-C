struct elevator {
    int busy; //=0
    int floor;

};
