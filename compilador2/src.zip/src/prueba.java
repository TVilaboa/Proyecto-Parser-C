/**
 * Created by IntelliJ IDEA.
 * User: Ignacio
 * Date: 25/10/12
 * Time: 16:10
 * To change this template use File | Settings | File Templates.
 */
public class prueba {
    public static void main (String args){
        System.out.println("asf");
    }
}
