package compiler;

/**
 * User: Javier Isoldi
 * Date: 3/15/13
 * Time: 11:49 AM
 */
public class InvalidExpressionException extends Exception{
    public InvalidExpressionException(String message) {
        super(message);
    }


}
