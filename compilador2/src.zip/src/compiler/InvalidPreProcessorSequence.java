package compiler;

/**
 * User: Javier Isoldi
 * Date: 3/25/13
 * Time: 11:04 PM
 */
public class InvalidPreProcessorSequence extends Exception {
}
